from django.apps import AppConfig

"""Accounts 应用配置。"""


class AccountsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "accounts"
